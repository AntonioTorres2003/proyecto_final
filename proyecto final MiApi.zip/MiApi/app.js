const express = require('express')
const app = express()
const router = require('./DB/Routes')

app.use(express.json());
app.use()

app.listen(3000)